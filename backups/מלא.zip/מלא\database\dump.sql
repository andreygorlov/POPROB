-- SQL Dump Generated at 2025-09-26T11:09:25.560Z

-- Table: Account
CREATE TABLE IF NOT EXISTS Account (
  -- Table structure would go here
);

-- Table: Session
CREATE TABLE IF NOT EXISTS Session (
  -- Table structure would go here
);

-- Table: User
CREATE TABLE IF NOT EXISTS User (
  -- Table structure would go here
);

-- Data for User
INSERT INTO User VALUES ('cmg0nsh2p001wl25yq1wtewwz', 'מנהל מערכת', 'admin@company.com', , , Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');

-- Table: VerificationToken
CREATE TABLE IF NOT EXISTS VerificationToken (
  -- Table structure would go here
);

-- Table: Role
CREATE TABLE IF NOT EXISTS Role (
  -- Table structure would go here
);

-- Data for Role
INSERT INTO Role VALUES ('cmg0nsgxi0000l25ykgsxlln2', 'admin', 'מנהל מערכת - גישה מלאה', Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Role VALUES ('cmg0nsgxp0001l25ys15arxvb', 'manager', 'מנהל - גישה למודולים מוקצים', Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Role VALUES ('cmg0nsgxt0002l25ygdjy69ai', 'employee', 'עובד - גישה מוגבלת', Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Role VALUES ('cmg0nsgxy0003l25ysryh8jht', 'viewer', 'צופה - גישה לקריאה בלבד', Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), 'default');

-- Table: Permission
CREATE TABLE IF NOT EXISTS Permission (
  -- Table structure would go here
);

-- Data for Permission
INSERT INTO Permission VALUES ('cmg0nsgy30004l25yqy2mgftf', 'contacts:create', 'יצירת אנשי קשר', 'contacts', 'create', Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgy70005l25ylga85pjv', 'contacts:read', 'קריאת אנשי קשר', 'contacts', 'read', Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgyc0006l25yvrc8ze9g', 'contacts:update', 'עדכון אנשי קשר', 'contacts', 'update', Fri Sep 26 2025 12:48:06 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgyg0007l25ywmbnptm7', 'contacts:delete', 'מחיקת אנשי קשר', 'contacts', 'delete', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgyl0008l25ybdr5cpz7', 'hr:create', 'יצירת עובדים', 'hr', 'create', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgyp0009l25yv111h105', 'hr:read', 'קריאת עובדים', 'hr', 'read', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgyu000al25yssmpsok1', 'hr:update', 'עדכון עובדים', 'hr', 'update', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgyy000bl25yy2vgti47', 'hr:delete', 'מחיקת עובדים', 'hr', 'delete', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgz3000cl25y723sjaxw', 'production:create', 'יצירת פרויקטים', 'production', 'create', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgz7000dl25y7y0hzjob', 'production:read', 'קריאת פרויקטים', 'production', 'read', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgzc000el25yv0luh1g9', 'production:update', 'עדכון פרויקטים', 'production', 'update', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO Permission VALUES ('cmg0nsgzg000fl25yvwpri49n', 'production:delete', 'מחיקת פרויקטים', 'production', 'delete', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');

-- Table: UserRole
CREATE TABLE IF NOT EXISTS UserRole (
  -- Table structure would go here
);

-- Data for UserRole
INSERT INTO UserRole VALUES ('cmg0nsh2t001yl25ywomny7f6', 'cmg0nsh2p001wl25yq1wtewwz', 'cmg0nsgxi0000l25ykgsxlln2');

-- Table: RolePermission
CREATE TABLE IF NOT EXISTS RolePermission (
  -- Table structure would go here
);

-- Data for RolePermission
INSERT INTO RolePermission VALUES ('cmg0nsgzk000hl25ybm7otc7d', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgy30004l25yqy2mgftf');
INSERT INTO RolePermission VALUES ('cmg0nsgzp000jl25yc1g80kr0', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgy70005l25ylga85pjv');
INSERT INTO RolePermission VALUES ('cmg0nsgzt000ll25yha0dxi4k', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgyc0006l25yvrc8ze9g');
INSERT INTO RolePermission VALUES ('cmg0nsgzx000nl25yyfoqaywd', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgyg0007l25ywmbnptm7');
INSERT INTO RolePermission VALUES ('cmg0nsh02000pl25yj5gvog04', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgyl0008l25ybdr5cpz7');
INSERT INTO RolePermission VALUES ('cmg0nsh06000rl25yu0nj12o5', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgyp0009l25yv111h105');
INSERT INTO RolePermission VALUES ('cmg0nsh0a000tl25yhd0i8bdg', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgyu000al25yssmpsok1');
INSERT INTO RolePermission VALUES ('cmg0nsh0e000vl25y27udpn4x', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgyy000bl25yy2vgti47');
INSERT INTO RolePermission VALUES ('cmg0nsh0j000xl25ydu0657zl', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgz3000cl25y723sjaxw');
INSERT INTO RolePermission VALUES ('cmg0nsh0n000zl25yal47w4sf', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgz7000dl25y7y0hzjob');
INSERT INTO RolePermission VALUES ('cmg0nsh0s0011l25yi74jh23k', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgzc000el25yv0luh1g9');
INSERT INTO RolePermission VALUES ('cmg0nsh0w0013l25yx330j10i', 'cmg0nsgxi0000l25ykgsxlln2', 'cmg0nsgzg000fl25yvwpri49n');
INSERT INTO RolePermission VALUES ('cmg0nsh110015l25y4533zw9v', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgy30004l25yqy2mgftf');
INSERT INTO RolePermission VALUES ('cmg0nsh150017l25ytab52pbv', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgy70005l25ylga85pjv');
INSERT INTO RolePermission VALUES ('cmg0nsh1a0019l25y6sl8bdkp', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgyc0006l25yvrc8ze9g');
INSERT INTO RolePermission VALUES ('cmg0nsh1e001bl25yc8qmw688', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgyl0008l25ybdr5cpz7');
INSERT INTO RolePermission VALUES ('cmg0nsh1i001dl25ykfdgvpyx', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgyp0009l25yv111h105');
INSERT INTO RolePermission VALUES ('cmg0nsh1m001fl25yy0rslzf1', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgyu000al25yssmpsok1');
INSERT INTO RolePermission VALUES ('cmg0nsh1r001hl25yl9limeb8', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgz3000cl25y723sjaxw');
INSERT INTO RolePermission VALUES ('cmg0nsh1u001jl25ybolo59ul', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgz7000dl25y7y0hzjob');
INSERT INTO RolePermission VALUES ('cmg0nsh1z001ll25ydkwwspcl', 'cmg0nsgxp0001l25ys15arxvb', 'cmg0nsgzc000el25yv0luh1g9');
INSERT INTO RolePermission VALUES ('cmg0nsh23001nl25ykjs4o0t0', 'cmg0nsgxt0002l25ygdjy69ai', 'cmg0nsgyp0009l25yv111h105');
INSERT INTO RolePermission VALUES ('cmg0nsh28001pl25yo4zwyt18', 'cmg0nsgxt0002l25ygdjy69ai', 'cmg0nsgz7000dl25y7y0hzjob');
INSERT INTO RolePermission VALUES ('cmg0nsh2c001rl25ypjng180q', 'cmg0nsgxy0003l25ysryh8jht', 'cmg0nsgy70005l25ylga85pjv');
INSERT INTO RolePermission VALUES ('cmg0nsh2g001tl25yyj0vj5yk', 'cmg0nsgxy0003l25ysryh8jht', 'cmg0nsgyp0009l25yv111h105');
INSERT INTO RolePermission VALUES ('cmg0nsh2k001vl25yoovszapx', 'cmg0nsgxy0003l25ysryh8jht', 'cmg0nsgz7000dl25y7y0hzjob');

-- Table: UserPermission
CREATE TABLE IF NOT EXISTS UserPermission (
  -- Table structure would go here
);

-- Table: Contact
CREATE TABLE IF NOT EXISTS Contact (
  -- Table structure would go here
);

-- Table: Employee
CREATE TABLE IF NOT EXISTS Employee (
  -- Table structure would go here
);

-- Table: Project
CREATE TABLE IF NOT EXISTS Project (
  -- Table structure would go here
);

-- Table: Task
CREATE TABLE IF NOT EXISTS Task (
  -- Table structure would go here
);

-- Table: ProjectContact
CREATE TABLE IF NOT EXISTS ProjectContact (
  -- Table structure would go here
);

-- Table: ProjectEmployee
CREATE TABLE IF NOT EXISTS ProjectEmployee (
  -- Table structure would go here
);

-- Table: AuditLog
CREATE TABLE IF NOT EXISTS AuditLog (
  -- Table structure would go here
);

-- Table: SystemConfig
CREATE TABLE IF NOT EXISTS SystemConfig (
  -- Table structure would go here
);

-- Data for SystemConfig
INSERT INTO SystemConfig VALUES ('cmg0nsh2y001zl25yqzvdzxrf', 'company_name', 'חברת דוגמה', 'string', 'general', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO SystemConfig VALUES ('cmg0nsh320020l25yc8gz8lik', 'default_currency', 'ILS', 'string', 'general', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO SystemConfig VALUES ('cmg0nsh360021l25y8als8kw9', 'timezone', 'Asia/Jerusalem', 'string', 'general', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO SystemConfig VALUES ('cmg0nsh3a0022l25ypuoqm2my', 'max_file_size', '10485760', 'number', 'general', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');
INSERT INTO SystemConfig VALUES ('cmg0nsh3f0023l25y2hhmjdh0', 'allowed_file_types', '["jpg", "jpeg", "png", "pdf", "doc", "docx"]', 'json', 'general', Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), Fri Sep 26 2025 12:48:07 GMT+0300 (Israel Daylight Time), 'default');

